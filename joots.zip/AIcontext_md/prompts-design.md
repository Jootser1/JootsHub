# Prompts Design   
"Un écran de chat moderne dans le style des applications de messagerie populaires comme iMessage, WhatsApp ou Messenger. Interface utilisateur avec une barre supérieure affichant le nom du contact et son avatar généré de manière aléatoire et ne représentant pas une personne, bulles de conversation rondes avec des couleurs différenciées pour l'expéditeur et le destinataire. 
Une grosse icone de JOOTS en bas à gauche et le formulaire pour taper au clavier, rajouter des emojis ou envoyer le message sur le reste de la barre.. Design réaliste et épuré avec des notifications et des timestamps pour chaque message."
Le tout respecte la charte graphique de JOOTS   
   
Blanc: #FFFFFF
Bleu: #5211CE
Vert: #3CBF77
Orange: #E59C45
Gris Clair: #E6E6E6
Gris Foncé: #999999   
   
Font de toute l'interface : Roboto   
Fond des réponses : Indie Flower   
   
