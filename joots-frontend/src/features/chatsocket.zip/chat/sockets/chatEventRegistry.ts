import { handleNewMessageEvent } from './chatEventHandlers';


export const chatEventRegistry = {
  newMessage: handleNewMessageEvent,

};






